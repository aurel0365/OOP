package pom;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class hibernateExample {

    public static Scanner myScanner = new Scanner(System.in);

    public static Connection getConnection() throws SQLException {
        // Update the database URL, username, and password accordingly
        String url = "jdbc:mysql://localhost:3306/student";
        String username = "root";
        String password = "";
        return DriverManager.getConnection(url, username, password);
    }

    public static String getInput(String message) {
        System.out.print(message);
        return myScanner.nextLine().trim();
    }

    public static int getInputInt(String message) {
        System.out.print(message);
        while (!myScanner.hasNextInt()) {
            System.out.println("Input harus berupa bilangan bulat.");
            myScanner.next(); // consume the non-integer input
        }
        return myScanner.nextInt();
    }

    public static void main(String[] args) {
        try (Connection connection = getConnection()) {
            boolean exit = false;
            while (!exit) {
                System.out.println("Pilih operasi yang ingin anda lakukan:");
                System.out.println("1. Insert");
                System.out.println("2. Update");
                System.out.println("3. Delete");
                System.out.println("4. Select");
                System.out.println("5. Exit");
                int choice = getInputInt("Masukkan pilihan anda: ");
                switch (choice) {
                    case 1:
                        insertStudent(connection);
                        break;
                    case 2:
                        updateStudent(connection);
                        break;
                    case 3:
                        deleteStudent(connection);
                        break;
                    case 4:
                        selectStudents(connection);
                        break;
                    case 5:
                        exit = true;
                        break;
                    default:
                        System.out.println("Pilihan tidak valid.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void insertStudent(Connection connection) throws SQLException {
        String name = getInput("Masukkan nama siswa: ");
        int age = getInputInt("Masukkan umur siswa: ");
        String major = getInput("Masukkan nama jurusan: ");
        String sql = "INSERT INTO Students (name, age, major) VALUES (?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, name);
            statement.setInt(2, age);
            statement.setString(3, major);
            statement.executeUpdate();
            System.out.println("Data siswa berhasil ditambahkan.");
        }
    }

    public static void updateStudent(Connection connection) throws SQLException {
        long id = getInputInt("Masukkan ID siswa yang ingin diupdate: ");
        String name = getInput("Masukkan nama siswa baru: ");
        int age = getInputInt("Masukkan umur siswa baru: ");
        String major = getInput("Masukkan nama jurusan baru: ");
        String sql = "UPDATE Students SET name = ?, age = ?, major = ? WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, name);
            statement.setInt(2, age);
            statement.setString(3, major);
            statement.setLong(4, id);
            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Data siswa berhasil diupdate.");
            } else {
                System.out.println("Siswa dengan ID tersebut tidak ditemukan.");
            }
        }
    }

    public static void deleteStudent(Connection connection) throws SQLException {
        long id = getInputInt("Masukkan ID siswa yang ingin dihapus: ");
        String sql = "DELETE FROM Students WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setLong(1, id);
            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Data siswa berhasil dihapus.");
            } else {
                System.out.println("Siswa dengan ID tersebut tidak ditemukan.");
            }
        }
    }

    public static void selectStudents(Connection connection) throws SQLException {
        String sql = "SELECT * FROM Students";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            ResultSet resultSet = statement.executeQuery();
            System.out.println("== Daftar Siswa ==");
            while (resultSet.next()) {
                long id = resultSet.getLong("id");
                String name = resultSet.getString("name");
                int age = resultSet.getInt("age");
                String major = resultSet.getString("major");
                System.out.println("ID: " + id + ", Nama: " + name + ", Umur: " + age + ", Jurusan: " + major);
            }
        }
    }
}
