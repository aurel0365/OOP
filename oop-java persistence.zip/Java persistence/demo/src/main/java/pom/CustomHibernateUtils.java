package pom;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class CustomHibernateUtils {
    private static final SessionFactory sessionFactory = buildSessionFactory();

    private static SessionFactory buildSessionFactory() {
        try {
            // Load configuration from custom configuration file (hibernate.custom.cfg.xml)
            Configuration configuration = new Configuration().configure("hibernate.custom.cfg.xml");
            return configuration.buildSessionFactory();
        } catch (Throwable ex) {
            throw new ExceptionInInitializerError(ex);
        }
    }

    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public static void shutdown() {
        getSessionFactory().close();
    }
}
