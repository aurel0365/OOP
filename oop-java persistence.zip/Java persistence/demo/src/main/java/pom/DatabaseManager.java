package pom;

import java.sql.Connection;

public class DatabaseManager {

    public static Connection getConnection() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getConnection'");
    }

}
